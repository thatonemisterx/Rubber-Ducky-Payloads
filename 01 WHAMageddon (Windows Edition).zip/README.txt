WHAM! Doomsday (Windows Edition) by thatonemisterx

This Rubber Ducky script is broken into two parts:

1. The Windows "Run" command is opened and the volume popup is pulled up through the "sndvol" command. The Page Up button is pushed four times to almost max out volume on a victim's computer.

2. The Windows "Run" command is opened again to send the victim to a file named "Interview Unedited" (this is Last Christmas by Wham! in disguise). The space bar is pushed to play the audio clip

There are two files in this ZIP file:

1. inject.bin - the actual inject file to paste into the Rubber Ducky if you want to get straight to the fun.
2. payload.txt - the script in a .txt file if you want to edit the payload to your liking (links for different songs/videos, timers to adjust timers because computer load times vary by device)

If you could, I would appreciate it if you check out my YouTube channel at www.youtube.com/@thatonemisterx

Happy trolling!

- Mister X