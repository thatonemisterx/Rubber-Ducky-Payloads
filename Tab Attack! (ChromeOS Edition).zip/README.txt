Tab Attack! (Windows Edition) by thatonemisterx

Description: This payload is designed to open a new tab on Google before spamming the "Open new window" keybind (CTRL + N). After running for a few seconds, the user has to either exit out of all of the tabs or turn off the Chromebook to delete the windows.

There are two files in this ZIP file:

1. inject.bin - the actual inject file to paste into the Rubber Ducky if you want to get straight to the fun.
2. payload.txt - the script in a .txt file if you want to see the code in plaintext.

If you could, I would appreciate it if you check out my YouTube channel at www.youtube.com/@thatonemisterx

Happy trolling!

- Mister X